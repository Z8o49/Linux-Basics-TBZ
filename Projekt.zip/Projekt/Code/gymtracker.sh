#!/bin/bash
# =============================================================================
# GymTracker CLI - Workout Tracking Tool
# Modul: M122 - Grundlagen der Scriptsprache BASH
# Autor: [Dein Name]
# Datum: 2026-05-07
# Version: 1.0
# =============================================================================

# ---- Konfiguration & Globale Variablen ----------------------------------------
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
DATA_DIR="$SCRIPT_DIR/gymtracker_data"
WORKOUTS_FILE="$DATA_DIR/workouts.csv"
LOG_FILE="$DATA_DIR/gymtracker.log"
RECORDS_FILE="$DATA_DIR/records.csv"

# Farben fuer die Ausgabe
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
CYAN='\033[0;36m'
BOLD='\033[1m'
NC='\033[0m' # No Color

# Verfuegbare Uebungen (Array)
EXERCISES=(
    "Bankdruecken"
    "Kniebeugen"
    "Kreuzheben"
    "Schulterpress"
    "Klimmzuege"
    "Bizepscurls"
    "Trizepsdrücken"
    "Beinpress"
    "Lat-Pulldown"
    "Rudern"
    "Eigene Übung"
)

# ---- Hilfsfunktionen ----------------------------------------------------------

# Logging-Funktion: Schreibt Eintraege mit Zeitstempel ins Logfile
log_message() {
    local level="$1"
    local message="$2"
    local timestamp
    timestamp=$(date "+%Y-%m-%d %H:%M:%S")
    echo "[$timestamp] [$level] $message" >> "$LOG_FILE"
}

# Trennlinie ausgeben
print_separator() {
    echo -e "${BLUE}================================================================${NC}"
}

# Header ausgeben
print_header() {
    clear
    print_separator
    echo -e "${BOLD}${CYAN}        🏋️  GymTracker CLI - Workout Journal  🏋️${NC}"
    print_separator
    echo ""
}

# Warte auf Tastendruck
press_enter() {
    echo ""
    echo -e "${YELLOW}[Enter druecken um fortzufahren...]${NC}"
    read -r
}

# Datenverzeichnis und Dateien erstellen falls nicht vorhanden
init_data() {
    if [ ! -d "$DATA_DIR" ]; then
        mkdir -p "$DATA_DIR"
        log_message "INFO" "Datenverzeichnis erstellt: $DATA_DIR"
    fi

    # CSV Header schreiben falls Dateien neu sind
    if [ ! -f "$WORKOUTS_FILE" ]; then
        echo "datum,uebung,gewicht_kg,saetze,wiederholungen,notiz" > "$WORKOUTS_FILE"
        log_message "INFO" "Workout-Datei erstellt"
    fi

    if [ ! -f "$RECORDS_FILE" ]; then
        echo "uebung,max_gewicht_kg,datum" > "$RECORDS_FILE"
        log_message "INFO" "Bestleistungs-Datei erstellt"
    fi

    if [ ! -f "$LOG_FILE" ]; then
        touch "$LOG_FILE"
        log_message "INFO" "GymTracker gestartet"
    fi
}

# Eingabe validieren: Ist es eine positive Zahl?
validate_number() {
    local input="$1"
    if [[ "$input" =~ ^[0-9]+(\.[0-9]+)?$ ]] && (( $(echo "$input > 0" | bc -l) )); then
        return 0
    else
        return 1
    fi
}

# Bestleistung aktualisieren
update_record() {
    local exercise="$1"
    local weight="$2"
    local date="$3"

    # Aktuelle Bestleistung fuer diese Uebung suchen
    local current_record
    current_record=$(grep "^${exercise}," "$RECORDS_FILE" 2>/dev/null | head -1 | cut -d',' -f2)

    if [ -z "$current_record" ]; then
        # Kein Eintrag vorhanden -> neu anlegen
        echo "${exercise},${weight},${date}" >> "$RECORDS_FILE"
        log_message "INFO" "Neue Bestleistung fuer $exercise: ${weight}kg"
        echo -e "${GREEN}🏆 Neue Uebung eingetragen: ${exercise} mit ${weight}kg!${NC}"
    elif (( $(echo "$weight > $current_record" | bc -l) )); then
        # Neuer Rekord! Zeile ersetzen
        local tmp_file
        tmp_file=$(mktemp)
        grep -v "^${exercise}," "$RECORDS_FILE" > "$tmp_file"
        echo "${exercise},${weight},${date}" >> "$tmp_file"
        mv "$tmp_file" "$RECORDS_FILE"
        log_message "INFO" "Neuer Rekord fuer $exercise: ${weight}kg (vorher: ${current_record}kg)"
        echo -e "${GREEN}🏆 NEUER REKORD fuer ${exercise}: ${weight}kg (vorher: ${current_record}kg)!${NC}"
    fi
}

# ---- Hauptfunktionen ----------------------------------------------------------

# Workout eintragen
add_workout() {
    print_header
    echo -e "${BOLD}📝 Neues Workout eintragen${NC}"
    print_separator
    echo ""

    # Datum
    local date
    date=$(date "+%Y-%m-%d")
    echo -e "Datum: ${CYAN}$date${NC}"
    echo ""

    # Uebung auswaehlen
    echo -e "${BOLD}Uebung auswaehlen:${NC}"
    local i=1
    for exercise in "${EXERCISES[@]}"; do
        echo -e "  ${CYAN}[$i]${NC} $exercise"
        ((i++))
    done
    echo ""

    local choice
    while true; do
        read -rp "Auswahl (1-${#EXERCISES[@]}): " choice
        if [[ "$choice" =~ ^[0-9]+$ ]] && [ "$choice" -ge 1 ] && [ "$choice" -le "${#EXERCISES[@]}" ]; then
            break
        fi
        echo -e "${RED}Ungueltige Eingabe. Bitte 1-${#EXERCISES[@]} eingeben.${NC}"
    done

    local exercise_name="${EXERCISES[$((choice-1))]}"

    # Falls "Eigene Uebung" gewaehlt
    if [ "$exercise_name" = "Eigene Übung" ]; then
        read -rp "Name der Uebung eingeben: " exercise_name
        if [ -z "$exercise_name" ]; then
            echo -e "${RED}Kein Name eingegeben. Abbruch.${NC}"
            press_enter
            return
        fi
    fi

    # Gewicht
    local weight
    while true; do
        read -rp "Gewicht in kg (z.B. 80 oder 82.5): " weight
        if validate_number "$weight"; then
            break
        fi
        echo -e "${RED}Ungueltige Eingabe. Bitte eine positive Zahl eingeben.${NC}"
    done

    # Saetze
    local sets
    while true; do
        read -rp "Anzahl Saetze: " sets
        if [[ "$sets" =~ ^[1-9][0-9]*$ ]]; then
            break
        fi
        echo -e "${RED}Ungueltige Eingabe. Bitte eine ganze Zahl > 0 eingeben.${NC}"
    done

    # Wiederholungen
    local reps
    while true; do
        read -rp "Wiederholungen pro Satz: " reps
        if [[ "$reps" =~ ^[1-9][0-9]*$ ]]; then
            break
        fi
        echo -e "${RED}Ungueltige Eingabe. Bitte eine ganze Zahl > 0 eingeben.${NC}"
    done

    # Optionale Notiz
    read -rp "Notiz (optional, Enter ueberspringen): " note
    note="${note//,/;}"  # Kommas ersetzen damit CSV nicht bricht

    # In CSV speichern
    echo "${date},${exercise_name},${weight},${sets},${reps},${note}" >> "$WORKOUTS_FILE"
    log_message "INFO" "Workout eingetragen: $exercise_name - ${weight}kg - ${sets}x${reps}"

    # Bestleistung pruefen
    update_record "$exercise_name" "$weight" "$date"

    # Volumen berechnen
    local volume
    volume=$(echo "$weight * $sets * $reps" | bc)

    echo ""
    print_separator
    echo -e "${GREEN}✅ Workout erfolgreich gespeichert!${NC}"
    echo -e "   Uebung:    ${CYAN}$exercise_name${NC}"
    echo -e "   Gewicht:   ${CYAN}${weight}kg${NC}"
    echo -e "   Saetze:    ${CYAN}$sets${NC}"
    echo -e "   Wdh:       ${CYAN}$reps${NC}"
    echo -e "   Volumen:   ${CYAN}${volume}kg${NC} (Gewicht x Saetze x Wdh)"
    print_separator

    press_enter
}

# Workout-Historie anzeigen
show_history() {
    print_header
    echo -e "${BOLD}📅 Workout-Historie (letzte 20 Eintraege)${NC}"
    print_separator
    echo ""

    # Pruefen ob Eintraege vorhanden (ausser Header)
    local count
    count=$(tail -n +2 "$WORKOUTS_FILE" | wc -l)

    if [ "$count" -eq 0 ]; then
        echo -e "${YELLOW}Noch keine Workouts eingetragen.${NC}"
        press_enter
        return
    fi

    # Header
    printf "${BOLD}%-12s %-20s %-10s %-6s %-6s %-20s${NC}\n" \
        "Datum" "Uebung" "Gewicht" "Saetze" "Wdh" "Notiz"
    echo -e "${BLUE}----------------------------------------------------------------${NC}"

    # Letzte 20 Eintraege ausgeben (umgekehrte Reihenfolge = neueste zuerst)
    tail -n +2 "$WORKOUTS_FILE" | tail -20 | while IFS=',' read -r date exercise weight sets reps note; do
        printf "%-12s %-20s %-10s %-6s %-6s %-20s\n" \
            "$date" "$exercise" "${weight}kg" "$sets" "$reps" "$note"
    done

    echo ""
    echo -e "Gesamt eingetragene Workouts: ${CYAN}$count${NC}"

    press_enter
}

# Bestleistungen anzeigen
show_records() {
    print_header
    echo -e "${BOLD}🏆 Persoenliche Bestleistungen${NC}"
    print_separator
    echo ""

    local count
    count=$(tail -n +2 "$RECORDS_FILE" | wc -l)

    if [ "$count" -eq 0 ]; then
        echo -e "${YELLOW}Noch keine Bestleistungen vorhanden.${NC}"
        press_enter
        return
    fi

    printf "${BOLD}%-25s %-15s %-12s${NC}\n" "Uebung" "Bestgewicht" "Datum"
    echo -e "${BLUE}----------------------------------------------------${NC}"

    tail -n +2 "$RECORDS_FILE" | sort -t',' -k2 -rn | while IFS=',' read -r exercise weight date; do
        printf "%-25s ${GREEN}%-15s${NC} %-12s\n" "$exercise" "${weight}kg" "$date"
    done

    press_enter
}

# Wochen-Statistik anzeigen
show_weekly_stats() {
    print_header
    echo -e "${BOLD}📊 Wochen-Statistik${NC}"
    print_separator
    echo ""

    # Aktuelle KW berechnen
    local current_week
    current_week=$(date "+%Y-W%V")
    local week_start
    week_start=$(date -d "last monday" "+%Y-%m-%d" 2>/dev/null || date -v-monday "+%Y-%m-%d" 2>/dev/null || date "+%Y-%m-%d")

    echo -e "Aktuelle Woche: ${CYAN}$current_week${NC}"
    echo ""

    # Workouts dieser Woche zaehlen
    local week_workouts
    week_workouts=$(tail -n +2 "$WORKOUTS_FILE" | awk -F',' -v start="$week_start" '$1 >= start' | wc -l)

    # Gesamtvolumen dieser Woche
    local total_volume
    total_volume=$(tail -n +2 "$WORKOUTS_FILE" | awk -F',' -v start="$week_start" '
        $1 >= start { vol += $3 * $4 * $5 }
        END { printf "%.1f", vol }
    ')

    echo -e "Trainingseinheiten diese Woche: ${CYAN}$week_workouts${NC}"
    echo -e "Gesamtvolumen diese Woche:      ${CYAN}${total_volume}kg${NC}"
    echo ""

    # Uebungen dieser Woche auflisten
    echo -e "${BOLD}Uebungen diese Woche:${NC}"
    echo -e "${BLUE}--------------------------------${NC}"

    local found=0
    tail -n +2 "$WORKOUTS_FILE" | awk -F',' -v start="$week_start" '
        $1 >= start { print $2 "," $3 "," $4 "," $5 }
    ' | sort | while IFS=',' read -r exercise weight sets reps; do
        local vol
        vol=$(echo "$weight * $sets * $reps" | bc)
        printf "  %-20s %skg  %sx%s  Vol: %skg\n" "$exercise" "$weight" "$sets" "$reps" "$vol"
        found=1
    done

    if [ "$week_workouts" -eq 0 ]; then
        echo -e "  ${YELLOW}Diese Woche noch kein Training eingetragen.${NC}"
    fi

    # Letzte 4 Wochen Vergleich
    echo ""
    echo -e "${BOLD}Trainingstage letzte 4 Wochen:${NC}"
    echo -e "${BLUE}--------------------------------${NC}"

    for i in 0 1 2 3; do
        local week_label
        week_label=$(date -d "$((i * 7)) days ago" "+%Y-W%V" 2>/dev/null || date "+%Y-W%V")
        local wstart
        wstart=$(date -d "$((i * 7)) days ago monday" "+%Y-%m-%d" 2>/dev/null || date "+%Y-%m-%d")
        local wend
        wend=$(date -d "$((i * 7 - 6)) days ago" "+%Y-%m-%d" 2>/dev/null || date "+%Y-%m-%d")

        local wcount
        wcount=$(tail -n +2 "$WORKOUTS_FILE" | awk -F',' -v s="$wstart" -v e="$wend" '
            $1 >= s && $1 <= e { count++ }
            END { print count+0 }
        ')

        # Balkendiagramm
        local bar=""
        for ((j=0; j<wcount; j++)); do
            bar="${bar}█"
        done

        if [ "$i" -eq 0 ]; then
            printf "  ${GREEN}%-12s${NC} | %-10s (%d Einheiten)\n" "$week_label" "$bar" "$wcount"
        else
            printf "  %-12s | %-10s (%d Einheiten)\n" "$week_label" "$bar" "$wcount"
        fi
    done

    press_enter
}

# Fortschritt einer Uebung anzeigen
show_exercise_progress() {
    print_header
    echo -e "${BOLD}📈 Fortschritt einer Uebung${NC}"
    print_separator
    echo ""

    # Alle Uebungen aus der Datei lesen
    local exercises_list
    mapfile -t exercises_list < <(tail -n +2 "$WORKOUTS_FILE" | cut -d',' -f2 | sort -u)

    if [ ${#exercises_list[@]} -eq 0 ]; then
        echo -e "${YELLOW}Noch keine Workouts vorhanden.${NC}"
        press_enter
        return
    fi

    echo -e "${BOLD}Uebungen mit Eintraegen:${NC}"
    local i=1
    for ex in "${exercises_list[@]}"; do
        echo -e "  ${CYAN}[$i]${NC} $ex"
        ((i++))
    done
    echo ""

    local choice
    while true; do
        read -rp "Uebung auswaehlen (1-${#exercises_list[@]}): " choice
        if [[ "$choice" =~ ^[0-9]+$ ]] && [ "$choice" -ge 1 ] && [ "$choice" -le "${#exercises_list[@]}" ]; then
            break
        fi
        echo -e "${RED}Ungueltige Eingabe.${NC}"
    done

    local selected="${exercises_list[$((choice-1))]}"
    echo ""
    echo -e "Fortschritt fuer: ${CYAN}${BOLD}$selected${NC}"
    echo -e "${BLUE}----------------------------------------${NC}"

    printf "${BOLD}%-12s %-10s %-6s %-6s %-12s${NC}\n" "Datum" "Gewicht" "Saetze" "Wdh" "Volumen"
    echo -e "${BLUE}----------------------------------------${NC}"

    # Eintraege fuer diese Uebung ausgeben
    local entry_count=0
    while IFS=',' read -r date exercise weight sets reps note; do
        if [ "$exercise" = "$selected" ]; then
            local vol
            vol=$(echo "$weight * $sets * $reps" | bc)
            printf "%-12s %-10s %-6s %-6s %-12s\n" "$date" "${weight}kg" "$sets" "$reps" "${vol}kg"
            ((entry_count++))
        fi
    done < <(tail -n +2 "$WORKOUTS_FILE")

    echo ""
    echo -e "Eintraege gesamt: ${CYAN}$entry_count${NC}"

    # Erster und letzter Eintrag vergleichen
    if [ "$entry_count" -ge 2 ]; then
        local first_weight last_weight
        first_weight=$(grep ",${selected}," "$WORKOUTS_FILE" | head -1 | cut -d',' -f3)
        last_weight=$(grep ",${selected}," "$WORKOUTS_FILE" | tail -1 | cut -d',' -f3)
        local diff
        diff=$(echo "$last_weight - $first_weight" | bc)
        if (( $(echo "$diff > 0" | bc -l) )); then
            echo -e "Fortschritt: ${GREEN}+${diff}kg seit dem ersten Eintrag 💪${NC}"
        elif (( $(echo "$diff < 0" | bc -l) )); then
            echo -e "Fortschritt: ${RED}${diff}kg seit dem ersten Eintrag${NC}"
        else
            echo -e "Fortschritt: ${YELLOW}Gleiches Gewicht wie beim ersten Eintrag${NC}"
        fi
    fi

    press_enter
}

# Wochenbericht generieren
generate_report() {
    print_header
    echo -e "${BOLD}📋 Wochenbericht generieren${NC}"
    print_separator
    echo ""

    local report_file="$DATA_DIR/wochenbericht_$(date '+%Y-%m-%d').txt"
    local timestamp
    timestamp=$(date "+%Y-%m-%d %H:%M:%S")

    {
        echo "================================================================"
        echo "  GYMTRACKER - WOCHENBERICHT"
        echo "  Erstellt am: $timestamp"
        echo "================================================================"
        echo ""

        echo "--- TRAININGSEINHEITEN GESAMT ---"
        local total
        total=$(tail -n +2 "$WORKOUTS_FILE" | wc -l)
        echo "Gesamte Trainingseinheiten: $total"
        echo ""

        echo "--- BESTLEISTUNGEN ---"
        if [ -f "$RECORDS_FILE" ]; then
            tail -n +2 "$RECORDS_FILE" | sort -t',' -k2 -rn | while IFS=',' read -r exercise weight date; do
                printf "%-25s %skg  (%s)\n" "$exercise" "$weight" "$date"
            done
        fi
        echo ""

        echo "--- LETZTE 10 WORKOUTS ---"
        printf "%-12s %-20s %-10s %-6s %-6s\n" "Datum" "Uebung" "Gewicht" "Saetze" "Wdh"
        echo "----------------------------------------------------------------"
        tail -n +2 "$WORKOUTS_FILE" | tail -10 | while IFS=',' read -r date exercise weight sets reps note; do
            printf "%-12s %-20s %-10s %-6s %-6s\n" "$date" "$exercise" "${weight}kg" "$sets" "$reps"
        done
        echo ""
        echo "================================================================"
        echo "  Ende des Berichts"
        echo "================================================================"
    } > "$report_file"

    log_message "INFO" "Wochenbericht erstellt: $report_file"

    echo -e "${GREEN}✅ Wochenbericht erstellt: ${CYAN}$report_file${NC}"
    echo ""
    echo -e "Bericht anzeigen? (j/n)"
    read -rp "> " show_report

    if [[ "$show_report" =~ ^[jJyY]$ ]]; then
        cat "$report_file"
    fi

    press_enter
}

# Logfile anzeigen
show_log() {
    print_header
    echo -e "${BOLD}🗒️  System-Log (letzte 20 Eintraege)${NC}"
    print_separator
    echo ""

    if [ ! -f "$LOG_FILE" ] || [ ! -s "$LOG_FILE" ]; then
        echo -e "${YELLOW}Logfile ist leer.${NC}"
    else
        tail -20 "$LOG_FILE"
    fi

    press_enter
}

# Cronjob einrichten
setup_cronjob() {
    print_header
    echo -e "${BOLD}⏰ Cronjob einrichten${NC}"
    print_separator
    echo ""
    echo -e "Der Cronjob erstellt taeglich um 08:00 Uhr einen automatischen"
    echo -e "Motivations-Reminder im Logfile und generiert jeden Sonntag"
    echo -e "einen Wochenbericht."
    echo ""

    local script_path
    script_path="$(realpath "$0")"

    # Aktuellen Crontab lesen
    local current_cron
    current_cron=$(crontab -l 2>/dev/null || echo "")

    # Pruefen ob Cronjob bereits existiert
    if echo "$current_cron" | grep -q "gymtracker"; then
        echo -e "${YELLOW}Ein GymTracker-Cronjob ist bereits eingerichtet:${NC}"
        echo ""
        echo "$current_cron" | grep "gymtracker"
        echo ""
        echo -e "Ersetzen? (j/n)"
        read -rp "> " replace
        if [[ ! "$replace" =~ ^[jJyY]$ ]]; then
            press_enter
            return
        fi
        # Alten Cronjob entfernen
        current_cron=$(echo "$current_cron" | grep -v "gymtracker")
    fi

    # Neuen Cronjob hinzufuegen
    # Taeglich 08:00: Motivations-Reminder ins Log
    # Sonntag 20:00: Wochenbericht generieren
    local new_cron
    new_cron="${current_cron}
# GymTracker - Taeglicher Reminder (08:00)
0 8 * * * echo \"[\$(date '+\%Y-\%m-\%d \%H:\%M:\%S')] [REMINDER] Vergiss dein Training nicht! 💪\" >> $DATA_DIR/gymtracker.log
# GymTracker - Wochen-Report (Sonntag 20:00)
0 20 * * 0 $script_path --report >> $DATA_DIR/gymtracker.log 2>&1"

    echo "$new_cron" | crontab -

    if [ $? -eq 0 ]; then
        echo -e "${GREEN}✅ Cronjob erfolgreich eingerichtet!${NC}"
        echo ""
        echo -e "Aktive Cronjobs:"
        crontab -l | grep "gymtracker"
        log_message "INFO" "Cronjob eingerichtet"
    else
        echo -e "${RED}❌ Fehler beim Einrichten des Cronjobs.${NC}"
        log_message "ERROR" "Cronjob konnte nicht eingerichtet werden"
    fi

    press_enter
}

# Alle Daten loeschen (mit Bestaetigung)
reset_data() {
    print_header
    echo -e "${RED}${BOLD}⚠️  ACHTUNG: Alle Daten loeschen${NC}"
    print_separator
    echo ""
    echo -e "${RED}Diese Aktion loescht ALLE Workout-Daten, Bestleistungen und Logs!${NC}"
    echo ""
    read -rp "Sicherheitsfrage - 'LOESCHEN' eingeben zum Bestaetigen: " confirm

    if [ "$confirm" = "LOESCHEN" ]; then
        rm -f "$WORKOUTS_FILE" "$RECORDS_FILE" "$LOG_FILE"
        init_data
        echo -e "${GREEN}Alle Daten wurden geloescht und neu initialisiert.${NC}"
        log_message "WARN" "Alle Daten wurden zurueckgesetzt"
    else
        echo -e "${YELLOW}Abgebrochen.${NC}"
    fi

    press_enter
}

# ---- Hauptmenue ---------------------------------------------------------------

show_menu() {
    print_header

    # Schnellinfo
    local total_workouts
    total_workouts=$(tail -n +2 "$WORKOUTS_FILE" 2>/dev/null | wc -l)
    local today
    today=$(date "+%Y-%m-%d")
    local today_workouts
    today_workouts=$(grep "^$today," "$WORKOUTS_FILE" 2>/dev/null | wc -l)

    echo -e "  Gesamt Eintraege: ${CYAN}$total_workouts${NC}  |  Heute: ${CYAN}$today_workouts${NC}  |  ${YELLOW}$(date '+%d.%m.%Y')${NC}"
    echo ""
    print_separator
    echo -e "${BOLD}  HAUPTMENUE${NC}"
    print_separator
    echo ""
    echo -e "  ${CYAN}[1]${NC} 📝 Workout eintragen"
    echo -e "  ${CYAN}[2]${NC} 📅 Workout-Historie anzeigen"
    echo -e "  ${CYAN}[3]${NC} 🏆 Bestleistungen anzeigen"
    echo -e "  ${CYAN}[4]${NC} 📊 Wochen-Statistik"
    echo -e "  ${CYAN}[5]${NC} 📈 Fortschritt einer Uebung"
    echo -e "  ${CYAN}[6]${NC} 📋 Wochenbericht generieren"
    echo -e "  ${CYAN}[7]${NC} ⏰ Cronjob einrichten"
    echo -e "  ${CYAN}[8]${NC} 🗒️  System-Log anzeigen"
    echo -e "  ${CYAN}[9]${NC} 🗑️  Alle Daten loeschen"
    echo -e "  ${CYAN}[0]${NC} 🚪 Beenden"
    echo ""
    print_separator
    read -rp "  Auswahl: " choice
    echo "$choice"
}

# ---- Kommandozeilen-Argumente -------------------------------------------------

# Automatischer Report fuer Cronjob
if [ "$1" = "--report" ]; then
    init_data
    log_message "INFO" "Automatischer Wochenbericht via Cronjob"
    report_file="$DATA_DIR/wochenbericht_$(date '+%Y-%m-%d').txt"
    total=$(tail -n +2 "$WORKOUTS_FILE" | wc -l)
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] [CRON] Wochenbericht: $total Eintraege total, Bericht: $report_file" >> "$LOG_FILE"
    exit 0
fi

# ---- Programmstart ------------------------------------------------------------

init_data
log_message "INFO" "GymTracker gestartet"

# Hauptschleife
while true; do
    choice=$(show_menu)

    case "$choice" in
        1) add_workout ;;
        2) show_history ;;
        3) show_records ;;
        4) show_weekly_stats ;;
        5) show_exercise_progress ;;
        6) generate_report ;;
        7) setup_cronjob ;;
        8) show_log ;;
        9) reset_data ;;
        0)
            echo ""
            echo -e "${GREEN}💪 Stay strong! Tschuess!${NC}"
            log_message "INFO" "GymTracker beendet"
            echo ""
            exit 0
            ;;
        *)
            echo -e "${RED}Ungueltige Eingabe. Bitte 0-9 waehlen.${NC}"
            sleep 1
            ;;
    esac
done
